

package com.example.demo.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Tour;


@Component("bs")
public class TourService {
	@Autowired
	private TourRepository TourRepo;
	
	public Tour create(Tour Tour) 
	{
		return TourRepo.save(Tour);
	}
	public List<Tour> read() 
	{
		return TourRepo.findAll();
	}
	public Tour read(String guideid) 
	{
		return TourRepo.findById(guideid).get();
	}
	public Tour update(Tour Tour) 
	{
		return TourRepo.save(Tour);
	}
	public void delete(String guideid) 
	{
		TourRepo.delete(read(guideid));
	}
}
