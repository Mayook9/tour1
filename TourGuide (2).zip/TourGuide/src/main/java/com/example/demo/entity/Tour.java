
package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TOUR")
public class Tour {
	@Id
	private String guideId;
	private String customerId;
	private String guideName;
	private String guidePhoneNo;

	public Tour() {}

	public Tour(String guideId, String customerId, String guideName, String guidePhoneNo) {
		super();
		this.guideId = guideId;
		this.customerId = customerId;
		this.guideName = guideName;
		this.guidePhoneNo = guidePhoneNo;
	}

	public String getGuideId() {
		return guideId;
	}

	public void setGuideId(String guideId) {
		this.guideId = guideId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getGuideName() {
		return guideName;
	}

	public void setGuideName(String guideName) {
		this.guideName = guideName;
	}

	public String getGuidePhoneNo() {
		return guidePhoneNo;
	}

	public void setGuidePhoneNo(String guidePhoneNo) {
		this.guidePhoneNo = guidePhoneNo;
	}
	
	
}
