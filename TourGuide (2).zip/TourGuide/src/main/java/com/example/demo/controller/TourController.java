
package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Tour;
import com.example.demo.model.TourService;

@RestController
@CrossOrigin(origins = {"http://http://localhost:4200/", "*"})
@RequestMapping("/Tour")
public class TourController {
	@Autowired
	 TourService bs;
	
	@PostMapping("/")
	public Tour addTour(@RequestBody Tour Tour)
	{
		return bs.create(Tour);
	}
	@GetMapping("/")
	public List<Tour> getAllToures()
	{
		return bs.read();
	}
	@GetMapping("/{guideid}")
	public Tour findTourById(@PathVariable("guideid") String guideid)
	{
		return bs.read(guideid);
	}
	@PutMapping("/")
	public Tour modifyTour(@RequestBody Tour Tour)
	{
		return bs.update(Tour);
	}
	@DeleteMapping("/{guideid}")
	public void removeTour(@PathVariable("guideid")String guideid)
	{
		bs.delete(guideid);
	}
}
