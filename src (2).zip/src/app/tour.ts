export class Tour {
    guideId:string="";
    customerId:string="";
    guideName:string="";
    guidePhoneNo:string="";
}
